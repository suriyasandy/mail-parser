
import os
import re
import nltk
from collections import Counter
from nlp.sentence_splitter import split_into_sentences

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOCAL_NLTK = os.path.join(PROJECT_ROOT, "nltk_data")
nltk.data.path.insert(0, LOCAL_NLTK)

from nltk.corpus import stopwords
_stopwords = set(stopwords.words("english"))

def summarize_by_frequency(text: str, top_n: int = 3) -> list[str]:
    sentences = split_into_sentences(text)
    if not sentences:
        return []

    words = [
        w.lower() for w in re.findall(r"\w+", text)
        if w.lower() not in _stopwords
    ]
    freq = Counter(words)

    scored = []
    for sent in sentences:
        sent_words = [w.lower() for w in re.findall(r"\w+", sent)]
        score = sum(freq[w] for w in sent_words)
        scored.append((sent, score))

    scored.sort(key=lambda x: x[1], reverse=True)
    top_sents = {s for s, _ in scored[:top_n]}
    return [s for s in sentences if s in top_sents]
