
import streamlit as st
from utils.summarizer import summarize_by_frequency
from nlp.sentence_splitter import split_into_sentences

st.set_page_config(page_title="Trade Entity Extraction", layout="wide")
st.title("Email-based Trade Entity Extraction System")

demo_text = st.text_area("Paste email text", height=150)
if demo_text.strip():
    st.subheader("📄 Thread Summary")
    summary_sents = summarize_by_frequency(demo_text.strip(), top_n=3)
    if summary_sents:
        for s in summary_sents:
            st.write("• " + s)
    else:
        st.write("—No summary available—")
