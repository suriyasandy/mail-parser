
import io
import pandas as pd

def extract_from_csv(data):
    return pd.read_csv(io.BytesIO(data))

def extract_from_xlsx(data):
    return pd.read_excel(io.BytesIO(data), engine='openpyxl')
