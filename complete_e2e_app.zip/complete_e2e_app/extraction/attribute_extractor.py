
import re
import spacy
from langdetect import detect

nlp = spacy.load("en_core_web_sm")

def extract_attributes_from_text(text):
    results = []
    # Regex for key: value pairs
    matches = re.findall(r'([A-Za-z0-9\s\-/()]+)[:\-–]\s*([^\n]+)', text)
    for attr, val in matches:
        results.append({"attribute": attr.strip(), "value": val.strip()})
    # spaCy NER
    doc = nlp(text)
    for ent in doc.ents:
        if ent.label_ in ("DATE","MONEY","PERCENT","QUANTITY"):
            context = ent.sent.text
            pre = context[:context.find(ent.text)].strip().split(" ")[-2:]
            attr_guess = " ".join(pre).strip(": -")
            if attr_guess and not any(r["value"]==ent.text for r in results):
                results.append({"attribute": attr_guess, "value": ent.text})
    return results

def track_value_history(lists):
    history = {}
    for attrs in lists:
        for d in attrs:
            key, val = d["attribute"], d["value"]
            history.setdefault(key, [])
            if not history[key] or history[key][-1]!=val:
                history[key].append(val)
    return history

def detect_language(text):
    try:
        return detect(text)
    except:
        return "unknown"
