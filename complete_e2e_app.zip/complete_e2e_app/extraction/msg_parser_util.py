
from msg_parser import MsOxMessage

def parse_msg_file(msg_file):
    msg = MsOxMessage(msg_file)
    # Extract thread chain by splitting by typical markers
    chain = []
    parts = msg.body.split('\nFrom:')
    html_parts = msg.htmlBody.split('<br>From:') if msg.htmlBody else parts
    for i, part in enumerate(parts):
        chain.append({
            "text_body": part.strip(),
            "html_body": html_parts[i].strip() if i < len(html_parts) else ""
        })
    return {"chain": chain, "attachments": msg.attachments}
