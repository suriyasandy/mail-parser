
import re
import pandas as pd
from bs4 import BeautifulSoup

def extract_tables_from_html(html):
    if not html:
        return []
    soup = BeautifulSoup(html, "html.parser")
    tables = soup.find_all("table")
    dfs = []
    for table in tables:
        try:
            dfs.append(pd.read_html(str(table))[0])
        except:
            pass
    return dfs

def extract_plaintext_tables(text):
    lines = text.split("\n")
    blocks, block = [], []
    for line in lines:
        if re.search(r'(\t| {2,}|\||,)', line) and line.strip():
            block.append(line)
        else:
            if len(block)>=2:
                blocks.append(block)
            block=[]
    if len(block)>=2:
        blocks.append(block)
    tables = []
    for b in blocks:
        sep = '\t' if '\t' in b[0] else ('|' if '|' in b[0] else (',' if ',' in b[0] else None))
        if sep:
            data = [row.split(sep) for row in b]
        else:
            data = [re.split(r' {2,}', row) for row in b]
        if all(not any(ch.isdigit() for ch in cell) for cell in data[0]):
            df = pd.DataFrame(data[1:], columns=data[0])
        else:
            cols = [f"col_{i+1}" for i in range(len(data[0]))]
            df = pd.DataFrame(data, columns=cols)
        tables.append(df)
    return tables
