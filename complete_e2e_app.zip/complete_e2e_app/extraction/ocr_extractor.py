
import easyocr
import io
from PIL import Image

reader = easyocr.Reader(['en'], gpu=False)

def extract_text_from_images(atts):
    results = []
    for att in atts:
        fname = att['longFilename'] or att['filename']
        if fname.lower().endswith(('.png','.jpg','.jpeg','.bmp','.tiff')):
            try:
                img = Image.open(io.BytesIO(att['data']))
                txt = "\n".join(reader.readtext(att['data'], detail=0))
                results.append({"filename": fname, "text": txt})
            except Exception as e:
                results.append({"filename": fname, "error": str(e)})
    return results
