
import io
import pdfplumber

def extract_text_from_pdf(pdf_bytes):
    pages = []
    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        for i, page in enumerate(pdf.pages):
            pages.append({"page": i+1, "text": page.extract_text()})
    return pages
