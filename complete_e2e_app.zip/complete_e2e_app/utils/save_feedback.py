
import json

def save_feedback(text, entities, feedback_path="feedback/feedback.jsonl"):
    feedback = {"text": text, "entities": []}
    cursor = 0
    for ent in entities:
        start = text.find(ent["text"], cursor)
        if start == -1:
            continue
        end = start + len(ent["text"])
        feedback["entities"].append([start, end, ent["label"]])
        cursor = end
    with open(feedback_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(feedback) + "\n")
