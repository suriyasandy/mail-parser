
# Email Entity Extraction PoC

## Overview
An end-to-end on-premise system for extracting trade-related entities from .msg emails.
Supports text, HTML tables, plaintext tables, OCR for images, and attachments (PDF, CSV, Excel).

## Setup
1. Create and activate a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   ```
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Download the base spaCy model:
   ```
   python -m spacy download en_core_web_sm
   ```
4. (Optional) Place a pretrained base model in `ner/base_model`.

## Usage
- Run the Streamlit app:
  ```
  streamlit run app.py
  ```
- Select your user role in the sidebar.
- Upload a `.msg` file or paste email text.
- Review and validate extracted entities.
- Download as CSV.
- Supervisors can submit feedback, saved in `feedback/feedback.jsonl`.
- Admins can retrain the NER model by clicking "Retrain Model".

## Retraining
Feedback is stored in `feedback/feedback.jsonl`. To retrain manually:
```
python ner/retrain.py
```
