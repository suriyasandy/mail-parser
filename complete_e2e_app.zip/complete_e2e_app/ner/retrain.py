
import spacy
from spacy.training.example import Example
import json

BASE_MODEL = "ner/base_model"
FEEDBACK_FILE = "feedback/feedback.jsonl"
OUTPUT_MODEL = "ner/trained_model"

def load_feedback():
    with open(FEEDBACK_FILE, "r", encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]

def train_model():
    nlp = spacy.load(BASE_MODEL)
    if "ner" not in nlp.pipe_names:
        ner = nlp.add_pipe("ner")
    else:
        ner = nlp.get_pipe("ner")

    data = load_feedback()
    examples = []
    for item in data:
        text = item["text"]
        ents = item.get("entities", [])
        doc = nlp.make_doc(text)
        examples.append(Example.from_dict(doc, {"entities": ents}))

    optimizer = nlp.resume_training()
    for epoch in range(10):
        for ex in examples:
            nlp.update([ex], drop=0.2, sgd=optimizer)

    nlp.to_disk(OUTPUT_MODEL)
    print(f"Model trained and saved to {OUTPUT_MODEL}")

if __name__ == "__main__":
    train_model()
